package cat.itacademy.barcelonactiva.SanchezMesa.JuanManuel.s04.t02.n01.S04T02N01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S04T02N01SanchezMesaJuanManuelApplicationTests {

	@Test
	void contextLoads() {
	}

}
